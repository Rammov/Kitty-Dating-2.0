import { Pool } from 'pg';

const db = new Pool({
  connectionString: process.env.DATABASE_URL || "postgresql://localhost:5432/mastra",
  ssl: false
});
const query = (text, params) => db.query(text, params);
const transaction = async (fn) => {
  const client = await db.connect();
  try {
    await client.query("BEGIN");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
};

export { db as d, query as q, transaction as t };
//# sourceMappingURL=db.mjs.map
